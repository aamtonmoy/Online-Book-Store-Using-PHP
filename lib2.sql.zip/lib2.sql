-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 20, 2017 at 01:30 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lib2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `un` varchar(50) DEFAULT NULL,
  `ps` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`un`, `ps`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `cat` varchar(50) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `img` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `name`, `cat`, `price`, `img`) VALUES
(5, 'Abrahman Linkin', 'Biography', '700', 'al1.jpg'),
(4, 'unique Dr APJ Kalam', 'Biography', '500', 'a.jpg'),
(6, 'Lincoln', 'Biography', '600', 'al3.jpg'),
(7, 'Morrow Lofe', 'Romentic', '300', 'r1.jpg'),
(8, 'MMLB', 'Romentic', '400', 'r2.jpg'),
(10, 'Nenja Ditective', 'Ditective', '350', 'd.jpg'),
(11, 'MCC', 'Ditective', '500', 'd1.jpg'),
(12, 'AC', 'Ditective', '220', 'd3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sell`
--

CREATE TABLE IF NOT EXISTS `sell` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bname` varchar(50) DEFAULT NULL,
  `bid` varchar(50) DEFAULT NULL,
  `name1` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `add1` varchar(50) DEFAULT NULL,
  `mno` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pin` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `sell`
--

INSERT INTO `sell` (`id`, `bname`, `bid`, `name1`, `city`, `add1`, `mno`, `email`, `pin`) VALUES
(8, 'To Denjeras For a Leady', '9', 'Deependra Baghel', 'ujjain', 'Ujjain', '9691626878', 'rajputds815@gmail.com', '456006');
